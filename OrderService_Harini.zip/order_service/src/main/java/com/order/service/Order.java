package com.order.service;

import jakarta.persistence.Entity;

@Entity
public class Order {

}


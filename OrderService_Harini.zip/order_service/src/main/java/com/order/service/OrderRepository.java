package com.order.service;

public interface OrderRepository {

}
